package com.stockmaster.msvccliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
